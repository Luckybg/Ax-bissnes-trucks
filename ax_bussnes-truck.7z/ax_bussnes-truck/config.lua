Config                        	= {}
Config.CopsScaleReward			= true

-- Change this to false if you want clean / legit money
Config.UsesBlackMoney			= false

--Hash of the npc ped. Change only if you know what you are doing.
Config.NPCHash					= 349680864 			

--Random time societies will get alerted. This is a range in seconds.
Config.AlertCopsDelayRangeStart	= 60
Config.AlertCopsDelayRangeEnd	= 70

--If you want to notify more societies add them here. example { "mafia", "bikers" }
Config.AlertExtraSocieties 		= { }

--Self Explained
Config.CargoProviderLocation	= { x = 1272.8, y = -1721.63, z = 53.90, h = 236.20 } 


Config.CargoDeliveryLocations 	= {

		{ x = 731.89, y = 4172.27, z = 39.3 },
		{ x = 1959.28, y = 3845.48, z = 31.2 },
		{ x = 388.76, y = 3591.34, z = 32.09},
		{ x = 97.24, y = 3739.86, z = 38.8}

}


Config.Scenarios = {
	
	{ 
		SpawnPoint = { x = 1288.44, y = -1729.61, z = 53.2, h = 117.09 },
		DeliveryPoint = 6.0,
		VehicleName = "fnvan",
		MinCopsOnline = 0,
		CargoCost = 2300,
		CargoReward = 5000
	
	},

	{ 
		SpawnPoint = { x = 1288.44, y = -1729.61, z = 53.2, h = 117.09 }, 
		DeliveryPoint = 6.0,
		VehicleName = "fnvan",
		MinCopsOnline = 0,
		CargoCost = 5000,
		CargoReward = 10000
	
	},
	{ 
		SpawnPoint = { x = 1288.44, y = -1729.61, z = 53.2, h = 117.09 },  
		DeliveryPoint = 6.0,
		VehicleName = "fnvan",
		MinCopsOnline = 0,
		CargoCost = 15000,
		CargoReward = 40000
	
	}
}